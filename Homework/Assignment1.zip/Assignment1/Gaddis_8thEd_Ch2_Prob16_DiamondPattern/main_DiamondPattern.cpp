/* 
 * File:   main.cpp
 * Author: Elise Chue
 * Created on June 23, 2016, 2:46 PM
 * Purpose: Display Diamond Pattern
 */

//System Libraries
#include <iostream>//Input/Output Stream Library
using namespace std;//Iostream uses the standard namespace

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables, no doubles
    //no variables. this is ASCII art  
    
    //Input data

    // Process data
    
    //Output data
    cout<<"   *   "<<endl;
    cout<<"  ***  "<<endl;
    cout<<" ***** "<<endl;
    cout<<"*******"<<endl;
    cout<<" ***** "<<endl;
    cout<<"  ***  "<<endl;
    cout<<"   *   "<<endl;
 
    //Exit Stage Right!
    return 0;
}

