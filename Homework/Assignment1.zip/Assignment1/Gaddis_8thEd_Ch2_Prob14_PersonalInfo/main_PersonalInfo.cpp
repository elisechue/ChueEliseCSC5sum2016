/* 
 * File:   main_PersonalInfo.cpp
 * Author: Elise Chue
 * Created on June 23, 2016, 3:54 PM
 * Purpose: Displaying Personal Info
 */

//System Libraries
#include <iostream>//Input/Output Stream Library
using namespace std;//Iostream uses the standard namespace

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables, no doubles
    
    //Input data

    // Process data
    
    //Output data
    cout<<"Elise Chue "<<endl<<"11465 Queensborough St. Riverside, CA, 92503"<<endl<<
          "(951)801-1492"<<endl<<"Industrial Engineer"<<endl;
    
    //^^^is code as directed by the book. Alternatively:
    //cout<<"Your name"<<endl;
    //cout<<"Your address, w/ city, state, and ZIP code"<<endl;
    //cout<<"Your telephone number"<<endl;
    //cout<<"Your college major"<<endl;
    
    //Exit Stage Right!
    return 0;
}

